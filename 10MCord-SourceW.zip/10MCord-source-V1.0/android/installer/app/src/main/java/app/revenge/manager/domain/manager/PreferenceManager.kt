package app.revenge.manager.domain.manager

import android.content.Context
import android.os.Build
import android.os.Environment
import androidx.annotation.StringRes
import app.revenge.manager.BuildConfig
import app.revenge.manager.R
import app.revenge.manager.domain.manager.base.BasePreferenceManager
import app.revenge.manager.utils.DiscordVersion
import app.revenge.manager.utils.installerCacheDir
import java.io.File
import java.util.concurrent.TimeUnit

class PreferenceManager(context: Context) :
    BasePreferenceManager(context.getSharedPreferences("prefs", Context.MODE_PRIVATE)) {

    val DEFAULT_MODULE_LOCATION = context.installerCacheDir.resolve("xposed.apk")

    /** Where the module was kept until 2026-11: the shared cache, which other apps could write to */
    private val legacyModuleLocations = listOfNotNull(
        context.externalCacheDir,
        File(Environment.getExternalStorageDirectory(), Environment.DIRECTORY_DOWNLOADS).resolve(BuildConfig.MANAGER_NAME),
    ).map { it.resolve("xposed.apk") }

    var packageName by stringPreference("package_name", BuildConfig.MODDED_APP_PACKAGE_NAME)

    var appName by stringPreference("app_name", BuildConfig.MOD_NAME)

    var discordVersion by stringPreference("discord_version", "")

    /** The newest signed release (its `sequence`) the module was taken from; an older one isn't taken again */
    var releaseSequence by stringPreference("release_sequence", "")

    /** What the app's own update notification carries, so only it can open the app straight into an install */
    var pendingInstallToken by stringPreference("pending_install_token", "")

    var patchIcon by booleanPreference("patch_icon", true)

    var debuggable by booleanPreference("debuggable", false)

    var mirror by enumPreference("mirror", Mirror.DEFAULT)

    var monet by booleanPreference("monet", false)

    var isDeveloper by booleanPreference("is_developer", false)

    var autoClearCache by booleanPreference("auto_clear_cache", true)

    var theme by enumPreference("theme", Theme.SYSTEM)

    var channel by enumPreference("channel", DiscordVersion.Type.STABLE)

    var updateDuration by enumPreference("update_duration", UpdateCheckerDuration.QUARTERLY)

    var moduleLocation by filePreference("module_location", DEFAULT_MODULE_LOCATION)

    var installMethod by enumPreference("install_method", InstallMethod.DEFAULT)

    var logsAlternateBackground by booleanPreference("logs_alternate_bg", true)

    var logsLineWrap by booleanPreference("logs_line_wrap", false)

    var allowDowngrade by booleanPreference("allow_downgrade", false)

    /** Where the Discord to patch comes from, when Discord is installed on the phone */
    var discordSource by enumPreference("discord_source", DiscordSource.INSTALLED)

    var hasAskedForBatteryOpt by booleanPreference("has_asked_for_battery_opt", false)

    /** Which 10MCord the home screen installs */
    var edition by enumPreference("edition", Edition.ENDCORD)

    init {
        if (mirror !in Mirror.entries) {
            mirror = Mirror.DEFAULT
        }
        // A module location reset to the old default is the default still, not a module of the user's own
        if (moduleLocation in legacyModuleLocations) {
            moduleLocation = DEFAULT_MODULE_LOCATION
        }
    }
}

enum class Theme(@StringRes val labelRes: Int) {
    SYSTEM(R.string.theme_system),
    LIGHT(R.string.theme_light),
    DARK(R.string.theme_dark)
}

enum class UpdateCheckerDuration(@StringRes val labelRes: Int, val time: Long, val unit: TimeUnit) {
    DISABLED(R.string.duration_disabled, 0, TimeUnit.SECONDS),
    QUARTERLY(R.string.duration_fifteen_min, 15, TimeUnit.MINUTES),
    HALF_HOUR(R.string.duration_half_hour, 30, TimeUnit.MINUTES),
    HOURLY(R.string.duration_hourly, 1, TimeUnit.HOURS),
    BIHOURLY(R.string.duration_bihourly, 2, TimeUnit.HOURS),
    TWICE_DAILY(R.string.duration_twice_daily, 12, TimeUnit.HOURS),
    DAILY(R.string.duration_daily, 1, TimeUnit.DAYS),
    WEEKLY(R.string.duration_weekly, 7, TimeUnit.DAYS)
}

enum class Mirror(val baseUrl: String) {
    DEFAULT("https://tracker.vendetta.rocks"),
    NEXPID("https://tracker.vd.nexpid.xyz"),
    USHIE("https://proxy.vd.ushie.dev")
}

enum class Edition {
    /** 10MCord on the current Discord app, installed here */
    ENDCORD,
    /** 10MCord Classic on Aliucord's older Discord, installed by its own installer */
    CLASSIC
}

enum class DiscordSource {
    /** The Discord already on the phone, usually from the Play Store */
    INSTALLED,
    /** A download of the latest Discord of the chosen channel */
    DOWNLOAD
}

enum class InstallMethod(@StringRes val labelRes: Int) {
    DEFAULT(R.string.default_installer),
    SHIZUKU(R.string.shizuku_installer)
}