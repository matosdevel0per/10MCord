/*
 * 10MCord for Android
 * Copyright (c) 2026 rootpoi and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Backs up 10MCord's settings to a file the user keeps, and restores them, like 10MCord PC's settings export.
 *
 * A backup only carries what is safe to take from a file someone else made: the language, which plugins are on and
 * their settings, what the user made with plugins (profiles, notes, collections...) and the addresses of their
 * themes and fonts. Developer settings stay out (DevTools on start or the eval command would let whoever made the file
 * run code in the app), and so do plugins from repositories, which are code, and the logs plugins keep.
 */

import { LANGUAGES, t } from "@core/i18n";
import { fonts, installFont, selectFont } from "@lib/addons/fonts";
import { corePluginInstances, pluginSettings } from "@lib/addons/plugins";
import { fetchTheme, getCurrentTheme, selectTheme, themes } from "@lib/addons/themes";
import { writeDocument } from "@lib/api/native/fs";
import { NativeFileModule } from "@lib/api/native/modules";
import { settings } from "@lib/api/settings";
import { awaitStorage, flushStorages } from "@lib/api/storage";
import { manifest } from "@plugins/manifest";
import { version } from "bunny-build-info";

const FORMAT = "10MCord-settings";
const VERSION = 1;
/** Larger than any backup 10MCord makes; a bigger file isn't one */
export const MAX_BACKUP_SIZE = 8 * 1024 * 1024;

/** The general settings a backup carries */
const SETTINGS_KEYS = ["language", "enableDiscordDeveloperSettings"] as const;

/**
 * Plugin settings a backup never carries, and that restoring one leaves as they are: secrets (API keys, passwords),
 * which a shared backup would give away, and the address ChatGPT sends its key to, which a backup someone else made
 * could point elsewhere
 */
const PRIVATE_SETTING = /^(api_?key|password|token|secret|base_?url)$/i;

const withoutPrivate = (store: JsonObject): JsonObject =>
    Object.fromEntries(Object.entries(store).filter(([key]) => !PRIVATE_SETTING.test(key)));
const onlyPrivate = (store: JsonObject | undefined): JsonObject =>
    Object.fromEntries(Object.entries(store ?? {}).filter(([key]) => PRIVATE_SETTING.test(key)));

/** Storages of what the user made with plugins; the logs and caches plugins keep for themselves aren't in backups */
const DATA_STORES = [
    "ENDCORD_BOOKMARKS", "ENDCORD_CHANNEL_NOTES", "ENDCORD_CUSTOM_PROFILE", "ENDCORD_CUSTOM_SOUNDS",
    "ENDCORD_FAKE_CONNECTIONS", "ENDCORD_FAKE_DMS", "ENDCORD_FAVORITE_MEDIA", "ENDCORD_FRIEND_NICKNAMES",
    "ENDCORD_FRIEND_TAGS", "ENDCORD_GIF_COLLECTIONS", "ENDCORD_MESSAGE_TAGS", "ENDCORD_MESSAGE_VAULT", "ENDCORD_PINS",
    "ENDCORD_PROFILE_SETS", "ENDCORD_STATUS_PRESETS", "ENDCORD_TEXT_REPLACE_RULES",
];

type Json = null | boolean | number | string | Json[] | { [key: string]: Json; };
type JsonObject = { [key: string]: Json; };

export interface Backup {
    format: typeof FORMAT;
    version: number;
    /** The 10MCord version that made it */
    10MCord: string;
    createdAt: string;
    settings: Partial<Record<typeof SETTINGS_KEYS[number], Json>>;
    /** Built-in plugins by ID, and whether each is on */
    plugins: Record<string, boolean>;
    /** 10MCord plugins' settings by plugin ID */
    pluginSettings: Record<string, JsonObject>;
    /** What the user made with plugins, by storage */
    data: Record<string, JsonObject>;
    themes: { urls: string[]; selected: string | null; };
    fonts: { urls: string[]; selected: string | null; };
}

const storePath = (name: string) => `vd_mmkv/${name}`;

async function readStore(name: string): Promise<JsonObject | undefined> {
    const path = `${NativeFileModule.getConstants().DocumentsDirPath}/${storePath(name)}`;
    if (!await NativeFileModule.fileExists(path)) return undefined;
    try {
        const data = JSON.parse(await NativeFileModule.readFile(path, "utf8"));
        return isPlainObject(data) ? data : undefined;
    } catch {
        return undefined;
    }
}

const writeStore = (name: string, data: JsonObject) => writeDocument(storePath(name), JSON.stringify(data));

function isPlainObject(value: unknown): value is JsonObject {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}

/** No key anywhere in it could change an object's prototype when copied, as 10MCord PC checks */
function isSafe(value: unknown, depth = 0): boolean {
    if (depth > 64) return false;
    if (typeof value !== "object" || value === null) return true;
    for (const key of Object.keys(value)) {
        if (key === "__proto__" || key === "constructor" || key === "prototype") return false;
        if (!isSafe((value as any)[key], depth + 1)) return false;
    }
    return true;
}

// Not with URL, which React Native only partly implements
const isHttps = (url: unknown): url is string => typeof url === "string" && /^https:\/\/\S+$/i.test(url);

/** 10MCord's settings as the text of a backup file */
export async function createBackup(): Promise<string> {
    await awaitStorage(pluginSettings);

    const plugins: Record<string, boolean> = {};
    for (const id of corePluginInstances.keys()) plugins[id] = Boolean(pluginSettings[id]?.enabled);

    const pluginStores: Record<string, JsonObject> = {};
    await Promise.all(manifest.filter(p => p.hasSettings).map(async p => {
        const store = await readStore(`ENDCORD_PLUGIN_${p.id}`);
        const shared = store && withoutPrivate(store);
        if (shared && Object.keys(shared).length) pluginStores[p.id] = shared;
    }));

    const data: Record<string, JsonObject> = {};
    await Promise.all(DATA_STORES.map(async name => {
        const store = await readStore(name);
        if (store && Object.keys(store).length) data[name] = store;
    }));

    const installedFonts = Object.entries(fonts).filter(([name]) => name !== "__selected") as [string, any][];
    const selectedFont = installedFonts.find(([name]) => name === fonts.__selected)?.[1]?.source;

    const backup: Backup = {
        format: FORMAT,
        version: VERSION,
        10MCord: version,
        createdAt: new Date().toISOString(),
        settings: Object.fromEntries(SETTINGS_KEYS.filter(k => settings[k] !== undefined).map(k => [k, settings[k] as Json])),
        plugins,
        pluginSettings: pluginStores,
        data,
        themes: {
            urls: Object.keys(themes).filter(isHttps),
            selected: getCurrentTheme()?.id ?? null,
        },
        fonts: {
            urls: installedFonts.map(([, font]) => font?.source).filter(isHttps),
            selected: isHttps(selectedFont) ? selectedFont : null,
        },
    };
    return JSON.stringify(backup, null, 2);
}

/** The backup in a file's text, keeping only what 10MCord takes from backups; throws, with a message to show, when it isn't one */
export function parseBackup(text: string): Backup {
    let parsed: any;
    try {
        parsed = JSON.parse(text);
    } catch {
        throw new Error(t("This file isn't an 10MCord backup"));
    }
    if (!isPlainObject(parsed) || parsed.format !== FORMAT || typeof parsed.version !== "number") {
        throw new Error(t("This file isn't an 10MCord backup"));
    }
    if (parsed.version > VERSION) throw new Error(t("This backup is from a newer 10MCord. Update 10MCord, then try again."));
    if (!isSafe(parsed)) throw new Error(t("This backup is damaged and can't be restored"));

    const object = (value: unknown): JsonObject => isPlainObject(value) ? value : {};
    const raw = object(parsed.settings);
    const backupSettings: Backup["settings"] = {};
    if (raw.language === "auto" || LANGUAGES.some(l => l.code === raw.language)) backupSettings.language = raw.language;
    if (typeof raw.enableDiscordDeveloperSettings === "boolean") backupSettings.enableDiscordDeveloperSettings = raw.enableDiscordDeveloperSettings;

    const plugins = Object.fromEntries(Object.entries(object(parsed.plugins))
        .filter(([id, on]) => corePluginInstances.has(id) && typeof on === "boolean")) as Record<string, boolean>;
    const pluginStores = Object.fromEntries(Object.entries(object(parsed.pluginSettings))
        .filter(([id, store]) => manifest.some(p => p.id === id) && isPlainObject(store))
        .map(([id, store]) => [id, withoutPrivate(store as JsonObject)])) as Record<string, JsonObject>;
    const data = Object.fromEntries(Object.entries(object(parsed.data))
        .filter(([name, store]) => DATA_STORES.includes(name) && isPlainObject(store))) as Record<string, JsonObject>;

    const addons = (value: unknown): Backup["themes"] => {
        const list = object(value);
        const urls = [...new Set(Array.isArray(list.urls) ? list.urls.filter(isHttps) : [])].slice(0, 200);
        return { urls, selected: typeof list.selected === "string" && urls.includes(list.selected) ? list.selected : null };
    };

    return {
        format: FORMAT,
        version: parsed.version,
        10MCord: typeof parsed.10MCord === "string" ? parsed.10MCord : "?",
        createdAt: typeof parsed.createdAt === "string" ? parsed.createdAt : "",
        settings: backupSettings,
        plugins,
        pluginSettings: pluginStores,
        data,
        themes: addons(parsed.themes),
        fonts: addons(parsed.fonts),
    };
}

/**
 * Replaces 10MCord's settings with a backup's. Discord should reload right after: plugins that are running hold their
 * settings in memory until then. Resolves to how many themes and fonts couldn't be installed again.
 */
export async function restoreBackup(backup: Backup): Promise<number> {
    await awaitStorage(pluginSettings);

    for (const key of SETTINGS_KEYS) {
        if (key in backup.settings) (settings as any)[key] = backup.settings[key];
    }
    for (const [id, enabled] of Object.entries(backup.plugins)) {
        pluginSettings[id] = { ...pluginSettings[id], enabled };
    }

    await Promise.all([
        ...Object.entries(backup.pluginSettings).map(async ([id, store]) => {
            const name = `ENDCORD_PLUGIN_${id}`;
            await writeStore(name, { ...store, ...onlyPrivate(await readStore(name)) });
        }),
        ...Object.entries(backup.data).map(([name, store]) => writeStore(name, store)),
    ]);

    const installedFonts = Object.entries(fonts).filter(([name]) => name !== "__selected") as [string, any][];
    const installed = await Promise.allSettled([
        ...backup.themes.urls.map(url => fetchTheme(url, url === backup.themes.selected)),
        ...backup.fonts.urls.map(async url => {
            // A font already here stays as it is, only selected if the backup had it selected
            const name = installedFonts.find(([, font]) => font?.source === url)?.[0];
            if (name === undefined) return installFont(url, url === backup.fonts.selected);
            if (url === backup.fonts.selected) await selectFont(name);
        }),
    ]);
    if (backup.themes.selected === null) await selectTheme(null);
    if (backup.fonts.selected === null && fonts.__selected) await selectFont(null);

    // The plugin manager saves which plugins are on a moment after a change; the reload must not come first
    await flushStorages();
    return installed.filter(r => r.status === "rejected").length;
}
