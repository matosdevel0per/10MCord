## [1.11.7](https://github.com/revenge-mod/revenge-bundle/compare/v1.11.6...v1.11.7) (2026-10-23)


### Bug Fixes

* chat background patch on 350+ ([aabec1b](https://github.com/revenge-mod/revenge-bundle/commit/aabec1bb3fa4ad1c785985b9d558d236fa2a0bf2))

## [1.11.6](https://github.com/revenge-mod/revenge-bundle/compare/v1.11.5...v1.11.6) (2026-08-27)


### Bug Fixes

* properly resolve design components ([#250](https://github.com/revenge-mod/revenge-bundle/issues/250)) ([6064541](https://github.com/revenge-mod/revenge-bundle/commit/60645417ee6f8940e8b68c23f3300077e5e6baed))
* update Plugins section icon ([4004e76](https://github.com/revenge-mod/revenge-bundle/commit/4004e76f7cc1344a62211b0b2192593dec430dad))

## [1.11.6-dev.2](https://github.com/revenge-mod/revenge-bundle/compare/v1.11.6-dev.1...v1.11.6-dev.2) (2026-08-27)


### Bug Fixes

* update Plugins section icon ([4004e76](https://github.com/revenge-mod/revenge-bundle/commit/4004e76f7cc1344a62211b0b2192593dec430dad))

## [1.11.6-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.11.5...v1.11.6-dev.1) (2026-08-27)


### Bug Fixes

* properly resolve design components ([#250](https://github.com/revenge-mod/revenge-bundle/issues/250)) ([6064541](https://github.com/revenge-mod/revenge-bundle/commit/60645417ee6f8940e8b68c23f3300077e5e6baed))

## [1.11.5](https://github.com/revenge-mod/revenge-bundle/compare/v1.11.4...v1.11.5) (2026-08-12)


### Bug Fixes

* skip bytecode compilation for the time being ([59a96a7](https://github.com/revenge-mod/revenge-bundle/commit/59a96a702c270d4bc7749ab41643b43d6f61ec56))

## [1.11.4](https://github.com/revenge-mod/revenge-bundle/compare/v1.11.3...v1.11.4) (2026-07-01)


### Bug Fixes

* compile with correct bytecode version ([9e1298f](https://github.com/revenge-mod/revenge-bundle/commit/9e1298f187bc779a253de6fa9e4cebd1a3393f9b))

## [1.11.3](https://github.com/revenge-mod/revenge-bundle/compare/v1.11.2...v1.11.3) (2026-07-01)


### Bug Fixes

* build script not finding hermesc ([e4c50ea](https://github.com/revenge-mod/revenge-bundle/commit/e4c50eafe7198ed4b3b6cd9f68a499b07effd4cb))
* update DevTools client to latest version ([304e022](https://github.com/revenge-mod/revenge-bundle/commit/304e022c09b7ed5ae4e8d0f092a4f9f1cc0c5177))

## [1.11.2](https://github.com/revenge-mod/revenge-bundle/compare/v1.11.1...v1.11.2) (2026-05-12)


### Bug Fixes

* settings crash after discord's settings refactor ([#233](https://github.com/revenge-mod/revenge-bundle/issues/233)) ([d321571](https://github.com/revenge-mod/revenge-bundle/commit/d321571dc6be9b3d0d967bcdd9a7378acd07b356))

## [1.11.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.11.0...v1.11.1) (2026-01-19)


### Bug Fixes

* themes on 307+ ([#217](https://github.com/revenge-mod/revenge-bundle/issues/217)) ([f383f05](https://github.com/revenge-mod/revenge-bundle/commit/f383f05d2c6926a406335758343b1de69cbf75cd))
* **ui:** use default color for Text ([d585bce](https://github.com/revenge-mod/revenge-bundle/commit/d585bce8f58cdfe626a2e2e276149fc3eb075a1e))

## [1.11.1-dev.2](https://github.com/revenge-mod/revenge-bundle/compare/v1.11.1-dev.1...v1.11.1-dev.2) (2026-01-18)


### Bug Fixes

* themes on 307+ ([#217](https://github.com/revenge-mod/revenge-bundle/issues/217)) ([f383f05](https://github.com/revenge-mod/revenge-bundle/commit/f383f05d2c6926a406335758343b1de69cbf75cd))

## [1.11.1-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.11.0...v1.11.1-dev.1) (2025-12-17)


### Bug Fixes

* **ui:** use default color for Text ([d585bce](https://github.com/revenge-mod/revenge-bundle/commit/d585bce8f58cdfe626a2e2e276149fc3eb075a1e))

# [1.11.0](https://github.com/revenge-mod/revenge-bundle/compare/v1.10.5...v1.11.0) (2025-12-17)


### Bug Fixes

* fix more colors ([b26b0db](https://github.com/revenge-mod/revenge-bundle/commit/b26b0dbd80cd16b08703c5f3688697b8dc5e34f8))
* fixes for versions 309.5+ ([#215](https://github.com/revenge-mod/revenge-bundle/issues/215)) ([f20c37e](https://github.com/revenge-mod/revenge-bundle/commit/f20c37ea4ab9da3ed239bb9fa0d292393dcab187))
* **fonts:** re-add FontPreview ([8fe6c41](https://github.com/revenge-mod/revenge-bundle/commit/8fe6c41dad8e9b7a63a72bf42f899a98a25365d6))
* **fonts:** remove FontPreview ([8947785](https://github.com/revenge-mod/revenge-bundle/commit/8947785b609eaf892306a764b973260baa20853e))
* remove Skia ([3b864fb](https://github.com/revenge-mod/revenge-bundle/commit/3b864fb9e6cee86e9a25c385065dd0fd960bea02))
* **scripts:** fix \r for windows ([0c749f0](https://github.com/revenge-mod/revenge-bundle/commit/0c749f055794044e8ba4fd99680e3461764d26ab))
* update colors for 309.5 ([961340c](https://github.com/revenge-mod/revenge-bundle/commit/961340c0f1159f3a813310d273f9f2030792985d))


### Features

* add `react-native-webview` ([7fcf051](https://github.com/revenge-mod/revenge-bundle/commit/7fcf0510256fcc715cda200368f3bdf25e52fadd))
* **fonts:** memoize webview props ([a43af2c](https://github.com/revenge-mod/revenge-bundle/commit/a43af2cee9e43d989e39e59dd1c5ac9d7bdd12b4))
* **scripts:** skip hermes in `serve` script ([1185b47](https://github.com/revenge-mod/revenge-bundle/commit/1185b47de6cb9111da7c054303e7acde1b027ae7))

# [1.11.0-dev.3](https://github.com/revenge-mod/revenge-bundle/compare/v1.11.0-dev.2...v1.11.0-dev.3) (2025-12-17)


### Features

* **fonts:** memoize webview props ([a43af2c](https://github.com/revenge-mod/revenge-bundle/commit/a43af2cee9e43d989e39e59dd1c5ac9d7bdd12b4))

# [1.11.0-dev.2](https://github.com/revenge-mod/revenge-bundle/compare/v1.11.0-dev.1...v1.11.0-dev.2) (2025-12-17)


### Bug Fixes

* **fonts:** re-add FontPreview ([8fe6c41](https://github.com/revenge-mod/revenge-bundle/commit/8fe6c41dad8e9b7a63a72bf42f899a98a25365d6))


### Features

* add `react-native-webview` ([7fcf051](https://github.com/revenge-mod/revenge-bundle/commit/7fcf0510256fcc715cda200368f3bdf25e52fadd))

# [1.11.0-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.10.5...v1.11.0-dev.1) (2025-12-17)


### Bug Fixes

* fix more colors ([b26b0db](https://github.com/revenge-mod/revenge-bundle/commit/b26b0dbd80cd16b08703c5f3688697b8dc5e34f8))
* **fonts:** remove FontPreview ([8947785](https://github.com/revenge-mod/revenge-bundle/commit/8947785b609eaf892306a764b973260baa20853e))
* remove Skia ([3b864fb](https://github.com/revenge-mod/revenge-bundle/commit/3b864fb9e6cee86e9a25c385065dd0fd960bea02))
* **scripts:** fix \r for windows ([0c749f0](https://github.com/revenge-mod/revenge-bundle/commit/0c749f055794044e8ba4fd99680e3461764d26ab))
* update colors for 309.5 ([961340c](https://github.com/revenge-mod/revenge-bundle/commit/961340c0f1159f3a813310d273f9f2030792985d))


### Features

* **scripts:** skip hermes in `serve` script ([1185b47](https://github.com/revenge-mod/revenge-bundle/commit/1185b47de6cb9111da7c054303e7acde1b027ae7))

## [1.10.5](https://github.com/revenge-mod/revenge-bundle/compare/v1.10.4...v1.10.5) (2025-11-14)


### Bug Fixes

* **settings:** add missing import ([4bb3339](https://github.com/revenge-mod/revenge-bundle/commit/4bb333990edfdd6e9aa14a7e16e04c08c5438fde))

## [1.10.4](https://github.com/revenge-mod/revenge-bundle/compare/v1.10.3...v1.10.4) (2025-11-14)


### Bug Fixes

* **settings:** correct settings injecting into every menu  ([#211](https://github.com/revenge-mod/revenge-bundle/issues/211)) ([e261747](https://github.com/revenge-mod/revenge-bundle/commit/e2617470a80b2eba6eef750e622ad45b0dc63876))

## [1.10.3](https://github.com/revenge-mod/revenge-bundle/compare/v1.10.2...v1.10.3) (2025-11-14)


### Bug Fixes

* missing import in settings fix ([add81de](https://github.com/revenge-mod/revenge-bundle/commit/add81de302ee6198eabe194758807e129f3a7ef4))

## [1.10.2](https://github.com/revenge-mod/revenge-bundle/compare/v1.10.1...v1.10.2) (2025-11-14)


### Bug Fixes

* **settings:** add support for discord 306.4+ ([#208](https://github.com/revenge-mod/revenge-bundle/issues/208)) ([0076200](https://github.com/revenge-mod/revenge-bundle/commit/007620028e02511c37bfdfc538e3e5bc03034cde))

## [1.10.2-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.10.1...v1.10.2-dev.1) (2025-11-14)


### Bug Fixes

* **settings:** add support for discord 306.4+ ([#208](https://github.com/revenge-mod/revenge-bundle/issues/208)) ([0076200](https://github.com/revenge-mod/revenge-bundle/commit/007620028e02511c37bfdfc538e3e5bc03034cde))

## [1.10.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.10.0...v1.10.1) (2025-10-18)


### Bug Fixes

* **i18n:** replace `Debugger` with `DevTools` ([6bab54a](https://github.com/revenge-mod/revenge-bundle/commit/6bab54afe2c71d607a11dbf46ae72bfe84aa7c5d))

# [1.10.0](https://github.com/revenge-mod/revenge-bundle/compare/v1.9.0...v1.10.0) (2025-10-18)


### Bug Fixes

* **adb:** fix matching for multiple packages ([4279a88](https://github.com/revenge-mod/revenge-bundle/commit/4279a88b34fb6419ac1d71457349169f8864d632))
* **build:** mark `node:util` as external ([7052fd1](https://github.com/revenge-mod/revenge-bundle/commit/7052fd181071f79449d4b695a9262d3feb45dbd8))
* **build:** use wildcard instead of regex ([5d44e13](https://github.com/revenge-mod/revenge-bundle/commit/5d44e13bdde1e979e1c489fb254b78072c4f8a76))


### Features

* add autoconnect ([684e60f](https://github.com/revenge-mod/revenge-bundle/commit/684e60f52da6bc50b2d5f51099a39d9d143db26b))
* **build:** update `external` package regex ([e21f365](https://github.com/revenge-mod/revenge-bundle/commit/e21f36546e59373d110987d7dd78f672977c6768))
* improvements ([#204](https://github.com/revenge-mod/revenge-bundle/issues/204)) ([926fb1f](https://github.com/revenge-mod/revenge-bundle/commit/926fb1fa379341a4b8a0b63242e74bb5d4b287ff))
* modernify all icons ([ac77de7](https://github.com/revenge-mod/revenge-bundle/commit/ac77de7820ae8390fadbf5793ee58af1d054866b))
* reinstall devtools from npm ([0875e01](https://github.com/revenge-mod/revenge-bundle/commit/0875e01c3844724c6066581fa6bf3535b98f1a69))
* **ui:** don't use `isDisabled` ([e5a6e60](https://github.com/revenge-mod/revenge-bundle/commit/e5a6e606125ad4b57c8e1e8a09c64a483296412b))

# [1.10.0-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.9.0...v1.10.0-dev.1) (2025-10-18)


### Bug Fixes

* **adb:** fix matching for multiple packages ([4279a88](https://github.com/revenge-mod/revenge-bundle/commit/4279a88b34fb6419ac1d71457349169f8864d632))
* **build:** mark `node:util` as external ([7052fd1](https://github.com/revenge-mod/revenge-bundle/commit/7052fd181071f79449d4b695a9262d3feb45dbd8))
* **build:** use wildcard instead of regex ([5d44e13](https://github.com/revenge-mod/revenge-bundle/commit/5d44e13bdde1e979e1c489fb254b78072c4f8a76))


### Features

* add autoconnect ([684e60f](https://github.com/revenge-mod/revenge-bundle/commit/684e60f52da6bc50b2d5f51099a39d9d143db26b))
* **build:** update `external` package regex ([e21f365](https://github.com/revenge-mod/revenge-bundle/commit/e21f36546e59373d110987d7dd78f672977c6768))
* improvements ([#204](https://github.com/revenge-mod/revenge-bundle/issues/204)) ([926fb1f](https://github.com/revenge-mod/revenge-bundle/commit/926fb1fa379341a4b8a0b63242e74bb5d4b287ff))
* modernify all icons ([ac77de7](https://github.com/revenge-mod/revenge-bundle/commit/ac77de7820ae8390fadbf5793ee58af1d054866b))
* reinstall devtools from npm ([0875e01](https://github.com/revenge-mod/revenge-bundle/commit/0875e01c3844724c6066581fa6bf3535b98f1a69))
* **ui:** don't use `isDisabled` ([e5a6e60](https://github.com/revenge-mod/revenge-bundle/commit/e5a6e606125ad4b57c8e1e8a09c64a483296412b))

# [1.9.0](https://github.com/revenge-mod/revenge-bundle/compare/v1.8.1...v1.9.0) (2025-10-02)


### Bug Fixes

* Clear data -> Clear Data ([5b28d26](https://github.com/revenge-mod/revenge-bundle/commit/5b28d26db47c3783b9f447cb43bf8e47ac4b6673))
* slash commands not sending messages ([#201](https://github.com/revenge-mod/revenge-bundle/issues/201)) ([db2be1c](https://github.com/revenge-mod/revenge-bundle/commit/db2be1ca7ccfed659a143d3ac38d8eec81e731b0))
* update AssetId in Search component and AddonPage ([#200](https://github.com/revenge-mod/revenge-bundle/issues/200)) ([809214d](https://github.com/revenge-mod/revenge-bundle/commit/809214d082a294e52d260ed6a9fa034dea971c2c))


### Features

* enabled and disabled sort option for plugins ([#93](https://github.com/revenge-mod/revenge-bundle/issues/93)) ([388f2a6](https://github.com/revenge-mod/revenge-bundle/commit/388f2a632cfd07155aefb49902bd6174af8d467b))

# [1.9.0-dev.2](https://github.com/revenge-mod/revenge-bundle/compare/v1.9.0-dev.1...v1.9.0-dev.2) (2025-10-02)


### Bug Fixes

* Clear data -> Clear Data ([5b28d26](https://github.com/revenge-mod/revenge-bundle/commit/5b28d26db47c3783b9f447cb43bf8e47ac4b6673))

# [1.9.0-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.8.2-dev.2...v1.9.0-dev.1) (2025-10-02)


### Features

* enabled and disabled sort option for plugins ([#93](https://github.com/revenge-mod/revenge-bundle/issues/93)) ([388f2a6](https://github.com/revenge-mod/revenge-bundle/commit/388f2a632cfd07155aefb49902bd6174af8d467b))

## [1.8.2-dev.2](https://github.com/revenge-mod/revenge-bundle/compare/v1.8.2-dev.1...v1.8.2-dev.2) (2025-10-02)


### Bug Fixes

* update AssetId in Search component and AddonPage ([#200](https://github.com/revenge-mod/revenge-bundle/issues/200)) ([809214d](https://github.com/revenge-mod/revenge-bundle/commit/809214d082a294e52d260ed6a9fa034dea971c2c))

## [1.8.2-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.8.1...v1.8.2-dev.1) (2025-09-26)


### Bug Fixes

* slash commands not sending messages ([#201](https://github.com/revenge-mod/revenge-bundle/issues/201)) ([db2be1c](https://github.com/revenge-mod/revenge-bundle/commit/db2be1ca7ccfed659a143d3ac38d8eec81e731b0))

## [1.8.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.8.0...v1.8.1) (2025-07-24)


### Bug Fixes

* **api/patcher:** assert delayCallback ([#196](https://github.com/revenge-mod/revenge-bundle/issues/196)) ([5bc8868](https://github.com/revenge-mod/revenge-bundle/commit/5bc886868def333812dfc2b8d3c90d51e7739852))
* make React DevTools work again ([d659983](https://github.com/revenge-mod/revenge-bundle/commit/d6599831e6bf78afad77eb1b4e1f820f6a34139e))

## [1.8.1-dev.2](https://github.com/revenge-mod/revenge-bundle/compare/v1.8.1-dev.1...v1.8.1-dev.2) (2025-07-24)


### Bug Fixes

* make React DevTools work again ([d659983](https://github.com/revenge-mod/revenge-bundle/commit/d6599831e6bf78afad77eb1b4e1f820f6a34139e))

## [1.8.1-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.8.0...v1.8.1-dev.1) (2025-07-22)


### Bug Fixes

* **api/patcher:** assert delayCallback ([#196](https://github.com/revenge-mod/revenge-bundle/issues/196)) ([5bc8868](https://github.com/revenge-mod/revenge-bundle/commit/5bc886868def333812dfc2b8d3c90d51e7739852))

# [1.8.0](https://github.com/revenge-mod/revenge-bundle/compare/v1.7.4...v1.8.0) (2025-07-21)


### Bug Fixes

* Restore original behavior broken by b92d2734b33d2f0e719c364ed5aaefd43c7ae457 ([ec2809f](https://github.com/revenge-mod/revenge-bundle/commit/ec2809fe4c835c84101a8b8525cfc3863d1bc4d8))
* Restore original behavior broken for old architecture ([#194](https://github.com/revenge-mod/revenge-bundle/issues/194)) ([acb85ba](https://github.com/revenge-mod/revenge-bundle/commit/acb85bacbab8b661c797f3b1609e64f2c724382f))
* support New Architecture ([b92d273](https://github.com/revenge-mod/revenge-bundle/commit/b92d2734b33d2f0e719c364ed5aaefd43c7ae457))
* support versions with New Architecture ([#193](https://github.com/revenge-mod/revenge-bundle/issues/193)) ([1b96867](https://github.com/revenge-mod/revenge-bundle/commit/1b96867ac76e522616186e96120c940b9311d659))


### Features

* compile to bytecode ([18f21fe](https://github.com/revenge-mod/revenge-bundle/commit/18f21feaaea0a4330e2b098c549b2a516cc8d352))

# [1.8.0-dev.2](https://github.com/revenge-mod/revenge-bundle/compare/v1.8.0-dev.1...v1.8.0-dev.2) (2025-07-21)


### Bug Fixes

* Restore original behavior broken by b92d2734b33d2f0e719c364ed5aaefd43c7ae457 ([ec2809f](https://github.com/revenge-mod/revenge-bundle/commit/ec2809fe4c835c84101a8b8525cfc3863d1bc4d8))
* Restore original behavior broken for old architecture ([#194](https://github.com/revenge-mod/revenge-bundle/issues/194)) ([acb85ba](https://github.com/revenge-mod/revenge-bundle/commit/acb85bacbab8b661c797f3b1609e64f2c724382f))

# [1.8.0-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.7.5-dev.1...v1.8.0-dev.1) (2025-07-21)


### Features

* compile to bytecode ([18f21fe](https://github.com/revenge-mod/revenge-bundle/commit/18f21feaaea0a4330e2b098c549b2a516cc8d352))

# [1.8.0-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.7.5-dev.1...v1.8.0-dev.1) (2025-07-21)


### Features

* compile to bytecode ([18f21fe](https://github.com/revenge-mod/revenge-bundle/commit/18f21feaaea0a4330e2b098c549b2a516cc8d352))

# [1.8.0-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.7.5-dev.1...v1.8.0-dev.1) (2025-07-21)


### Features

* compile to bytecode ([18f21fe](https://github.com/revenge-mod/revenge-bundle/commit/18f21feaaea0a4330e2b098c549b2a516cc8d352))

# [1.8.0-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.7.5-dev.1...v1.8.0-dev.1) (2025-07-21)


### Features

* compile to bytecode ([18f21fe](https://github.com/revenge-mod/revenge-bundle/commit/18f21feaaea0a4330e2b098c549b2a516cc8d352))

## [1.7.5-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.7.4...v1.7.5-dev.1) (2025-07-21)


### Bug Fixes

* support New Architecture ([b92d273](https://github.com/revenge-mod/revenge-bundle/commit/b92d2734b33d2f0e719c364ed5aaefd43c7ae457))
* support versions with New Architecture ([#193](https://github.com/revenge-mod/revenge-bundle/issues/193)) ([1b96867](https://github.com/revenge-mod/revenge-bundle/commit/1b96867ac76e522616186e96120c940b9311d659))

## [1.7.4](https://github.com/revenge-mod/revenge-bundle/compare/v1.7.3...v1.7.4) (2025-05-19)


### Bug Fixes

* **core/patches/wrapSafeAreaProvider:** remove broken patch ([dfb0367](https://github.com/revenge-mod/revenge-bundle/commit/dfb036740a3789f171f16c2aca6f8db2de602d79))

## [1.7.3](https://github.com/revenge-mod/revenge-bundle/compare/v1.7.2...v1.7.3) (2025-05-19)


### Bug Fixes

* **metro/common:** polyfill `url` ([59ffa77](https://github.com/revenge-mod/revenge-bundle/commit/59ffa77a3aff59181d9dee169f91bda8e31c4400))

## [1.7.2](https://github.com/revenge-mod/revenge-bundle/compare/v1.7.1...v1.7.2) (2025-02-27)


### Bug Fixes

* **metro:** Blacklist IntlMessagesProxy exports ([e2a05a7](https://github.com/revenge-mod/revenge-bundle/commit/e2a05a77eef57d5eeea7204e93941278c4ed3340))
* **settings:** update tab index lookup approach ([821cbf0](https://github.com/revenge-mod/revenge-bundle/commit/821cbf01f2b16d8ba454fdbcf41efcb754607152))

## [1.7.2-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.7.1...v1.7.2-dev.1) (2025-02-27)


### Bug Fixes

* **metro:** Blacklist IntlMessagesProxy exports ([e2a05a7](https://github.com/revenge-mod/revenge-bundle/commit/e2a05a77eef57d5eeea7204e93941278c4ed3340))
* **settings:** update tab index lookup approach ([821cbf0](https://github.com/revenge-mod/revenge-bundle/commit/821cbf01f2b16d8ba454fdbcf41efcb754607152))

## [1.7.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.7.0...v1.7.1) (2025-02-14)


### Bug Fixes

* **settings:** update tab index lookup approach ([93c17e8](https://github.com/revenge-mod/revenge-bundle/commit/93c17e8e0c8597104d147d94da71078d6e368135))

## [1.7.1-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.7.0...v1.7.1-dev.1) (2025-02-14)


### Bug Fixes

* **settings:** update tab index lookup approach ([93c17e8](https://github.com/revenge-mod/revenge-bundle/commit/93c17e8e0c8597104d147d94da71078d6e368135))

# [1.7.0](https://github.com/revenge-mod/revenge-bundle/compare/v1.6.0...v1.7.0) (2025-02-02)


### Bug Fixes

* Adapt to change of `window.modules` being a Map ([78c303b](https://github.com/revenge-mod/revenge-bundle/commit/78c303b5f5eae283b082f96ef5923f2eac110e7c)), closes [#120](https://github.com/revenge-mod/revenge-bundle/issues/120)
* failsafe panel UI settings patching ([46a2c6e](https://github.com/revenge-mod/revenge-bundle/commit/46a2c6eaa16ca57f23f55881977f24ceb51e0d8b))
* **issue-template:** declare no plugin request [skip ci] ([87cfc74](https://github.com/revenge-mod/revenge-bundle/commit/87cfc742f65397297bd23d2950739ea1387c218c))
* **lib/api/native/modules:** add more native module fallbacks ([#102](https://github.com/revenge-mod/revenge-bundle/issues/102)) ([6f95203](https://github.com/revenge-mod/revenge-bundle/commit/6f95203dfa5beb3b48a9cc6061e712acd0ca8fb3)), closes [#99](https://github.com/revenge-mod/revenge-bundle/issues/99)
* **metro/patchNativeComponentRegistry:** return component name if fail ([26b7615](https://github.com/revenge-mod/revenge-bundle/commit/26b7615f84ea32302771323de1a8c252dfd2b7d1))
* **native:** update native modules name ([99c1266](https://github.com/revenge-mod/revenge-bundle/commit/99c12660f4857abe33ddc5b7056242b5c0ea8bcc))
* only show plugin browser on dev mode ([0817e53](https://github.com/revenge-mod/revenge-bundle/commit/0817e533de7537eec47d52b4fe385ae0f65ef5cd))
* pass IconComponent for settings section ([e80ab84](https://github.com/revenge-mod/revenge-bundle/commit/e80ab84b7cfe20acefc95954fb54b588eae89b7c))
* pass IconComponent for settings section ([e56ec77](https://github.com/revenge-mod/revenge-bundle/commit/e56ec778e0ab44611d27297d9ce258c43a70ac8f))
* **plugins:** filter out internal fields when loading plugins ([e141a62](https://github.com/revenge-mod/revenge-bundle/commit/e141a62dd06761d93f4ea957c32a7d4294253214))
* **plugins:** race condition when enabling plugin ([85c10af](https://github.com/revenge-mod/revenge-bundle/commit/85c10aff12866d0f491bb6560464c46b3323077a))
* readd semantic fallback for spec 2 themes ([0fd2107](https://github.com/revenge-mod/revenge-bundle/commit/0fd2107473c35334cc8ff2a548021469dadbbeb4))
* set bottom inset for floating buttons ([6f52993](https://github.com/revenge-mod/revenge-bundle/commit/6f52993838573cd133f128c1c0b8507524140a00))
* **themes:** use alternative way to patch chat background ([5ec4150](https://github.com/revenge-mod/revenge-bundle/commit/5ec41500b5c498d0ff45114af692961b0d1d574e)), closes [#123](https://github.com/revenge-mod/revenge-bundle/issues/123)
* **theme:** update validation logic ([c3cbc78](https://github.com/revenge-mod/revenge-bundle/commit/c3cbc78e13d5679f5ae0f9a79a8a24b0764a0d4f))
* **ui/reporter/ErrorBoundaryScreen:** move comment to a single line ([657c8eb](https://github.com/revenge-mod/revenge-bundle/commit/657c8ebd78df946a1aacd75c50e50b63920ebc2f))
* update file existence check to use object for prefix ([85cbac7](https://github.com/revenge-mod/revenge-bundle/commit/85cbac714a40d4afc273e9d710608c9094942412))
* wrap ErrorBoundaryScreen with SafeAreaProvider ([5e3f9b7](https://github.com/revenge-mod/revenge-bundle/commit/5e3f9b72361159da57c072cafed44424184d57f5))


### Features

* adopt dev metro ([cc87948](https://github.com/revenge-mod/revenge-bundle/commit/cc879485ac7d720c04191453865c677351b86f8c))
* **themes:** port more stuff from 'dev' ([0eb28e4](https://github.com/revenge-mod/revenge-bundle/commit/0eb28e41b7243fcae952ded5a7c44c274103d753))
* **ui/plugins:** Bunny plugin sheet impl ([c168237](https://github.com/revenge-mod/revenge-bundle/commit/c168237fc97bcf34353d6bf391f360cbccdbed84))
* **ui:** allow adding repository ([b5611d3](https://github.com/revenge-mod/revenge-bundle/commit/b5611d3cf185fd22b0a9adcffe3e473c3df7ca49))
* **ui:** update icons in About page ([ad9e05c](https://github.com/revenge-mod/revenge-bundle/commit/ad9e05c2034cbf82a2784bde7c50a4f40f70e03c))


### Performance Improvements

* **themes:** Draft rawColors normalization since writing directly is insanely slow for some reason ([e77e663](https://github.com/revenge-mod/revenge-bundle/commit/e77e6639d4a4d44f2f0cd0a9df708ea4f879d17b))

# [1.7.0-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.6.0...v1.7.0-dev.1) (2025-02-02)


### Bug Fixes

* Adapt to change of `window.modules` being a Map ([78c303b](https://github.com/revenge-mod/revenge-bundle/commit/78c303b5f5eae283b082f96ef5923f2eac110e7c)), closes [#120](https://github.com/revenge-mod/revenge-bundle/issues/120)
* failsafe panel UI settings patching ([46a2c6e](https://github.com/revenge-mod/revenge-bundle/commit/46a2c6eaa16ca57f23f55881977f24ceb51e0d8b))
* **issue-template:** declare no plugin request [skip ci] ([87cfc74](https://github.com/revenge-mod/revenge-bundle/commit/87cfc742f65397297bd23d2950739ea1387c218c))
* **lib/api/native/modules:** add more native module fallbacks ([#102](https://github.com/revenge-mod/revenge-bundle/issues/102)) ([6f95203](https://github.com/revenge-mod/revenge-bundle/commit/6f95203dfa5beb3b48a9cc6061e712acd0ca8fb3)), closes [#99](https://github.com/revenge-mod/revenge-bundle/issues/99)
* **metro/patchNativeComponentRegistry:** return component name if fail ([26b7615](https://github.com/revenge-mod/revenge-bundle/commit/26b7615f84ea32302771323de1a8c252dfd2b7d1))
* **native:** update native modules name ([99c1266](https://github.com/revenge-mod/revenge-bundle/commit/99c12660f4857abe33ddc5b7056242b5c0ea8bcc))
* only show plugin browser on dev mode ([0817e53](https://github.com/revenge-mod/revenge-bundle/commit/0817e533de7537eec47d52b4fe385ae0f65ef5cd))
* pass IconComponent for settings section ([e80ab84](https://github.com/revenge-mod/revenge-bundle/commit/e80ab84b7cfe20acefc95954fb54b588eae89b7c))
* pass IconComponent for settings section ([e56ec77](https://github.com/revenge-mod/revenge-bundle/commit/e56ec778e0ab44611d27297d9ce258c43a70ac8f))
* **plugins:** filter out internal fields when loading plugins ([e141a62](https://github.com/revenge-mod/revenge-bundle/commit/e141a62dd06761d93f4ea957c32a7d4294253214))
* **plugins:** race condition when enabling plugin ([85c10af](https://github.com/revenge-mod/revenge-bundle/commit/85c10aff12866d0f491bb6560464c46b3323077a))
* readd semantic fallback for spec 2 themes ([0fd2107](https://github.com/revenge-mod/revenge-bundle/commit/0fd2107473c35334cc8ff2a548021469dadbbeb4))
* set bottom inset for floating buttons ([6f52993](https://github.com/revenge-mod/revenge-bundle/commit/6f52993838573cd133f128c1c0b8507524140a00))
* **themes:** use alternative way to patch chat background ([5ec4150](https://github.com/revenge-mod/revenge-bundle/commit/5ec41500b5c498d0ff45114af692961b0d1d574e)), closes [#123](https://github.com/revenge-mod/revenge-bundle/issues/123)
* **theme:** update validation logic ([c3cbc78](https://github.com/revenge-mod/revenge-bundle/commit/c3cbc78e13d5679f5ae0f9a79a8a24b0764a0d4f))
* **ui/reporter/ErrorBoundaryScreen:** move comment to a single line ([657c8eb](https://github.com/revenge-mod/revenge-bundle/commit/657c8ebd78df946a1aacd75c50e50b63920ebc2f))
* update file existence check to use object for prefix ([85cbac7](https://github.com/revenge-mod/revenge-bundle/commit/85cbac714a40d4afc273e9d710608c9094942412))
* wrap ErrorBoundaryScreen with SafeAreaProvider ([5e3f9b7](https://github.com/revenge-mod/revenge-bundle/commit/5e3f9b72361159da57c072cafed44424184d57f5))


### Features

* adopt dev metro ([cc87948](https://github.com/revenge-mod/revenge-bundle/commit/cc879485ac7d720c04191453865c677351b86f8c))
* **themes:** port more stuff from 'dev' ([0eb28e4](https://github.com/revenge-mod/revenge-bundle/commit/0eb28e41b7243fcae952ded5a7c44c274103d753))
* **ui/plugins:** Bunny plugin sheet impl ([c168237](https://github.com/revenge-mod/revenge-bundle/commit/c168237fc97bcf34353d6bf391f360cbccdbed84))
* **ui:** allow adding repository ([b5611d3](https://github.com/revenge-mod/revenge-bundle/commit/b5611d3cf185fd22b0a9adcffe3e473c3df7ca49))
* **ui:** update icons in About page ([ad9e05c](https://github.com/revenge-mod/revenge-bundle/commit/ad9e05c2034cbf82a2784bde7c50a4f40f70e03c))


### Performance Improvements

* **themes:** Draft rawColors normalization since writing directly is insanely slow for some reason ([e77e663](https://github.com/revenge-mod/revenge-bundle/commit/e77e6639d4a4d44f2f0cd0a9df708ea4f879d17b))

# [1.6.0](https://github.com/revenge-mod/revenge-bundle/compare/v1.5.4...v1.6.0) (2025-01-23)


### Features

* support 263+ clients ([f1ba456](https://github.com/revenge-mod/revenge-bundle/commit/f1ba456474a85cbc291bdb320a16721bd6108483))

# [1.6.0-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.5.4...v1.6.0-dev.1) (2025-01-22)


### Features

* support 263+ clients ([f1ba456](https://github.com/revenge-mod/revenge-bundle/commit/f1ba456474a85cbc291bdb320a16721bd6108483))

## [1.5.4](https://github.com/revenge-mod/revenge-bundle/compare/v1.5.3...v1.5.4) (2024-12-26)


### Bug Fixes

* change `Bunny` to `Revenge` in `ErrorBoundary` content ([89f1b18](https://github.com/revenge-mod/revenge-bundle/commit/89f1b18ebb8995f9b26e3eaa83223cea54c0bc3d))
* **lib/ui/settings:** fix icon not showing up ([2fc7715](https://github.com/revenge-mod/revenge-bundle/commit/2fc7715fa4494c0b105a6399edc4877a155d3512))
* **ui/components/ErrorBoundaryScreen:** minor misspelling & update branding ([#57](https://github.com/revenge-mod/revenge-bundle/issues/57)) ([a71dd7d](https://github.com/revenge-mod/revenge-bundle/commit/a71dd7d0eb4c5e5003ff9743bcceab43ba2897c3))

## [1.5.4-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.5.3...v1.5.4-dev.1) (2024-12-26)


### Bug Fixes

* change `Bunny` to `Revenge` in `ErrorBoundary` content ([89f1b18](https://github.com/revenge-mod/revenge-bundle/commit/89f1b18ebb8995f9b26e3eaa83223cea54c0bc3d))
* **lib/ui/settings:** fix icon not showing up ([2fc7715](https://github.com/revenge-mod/revenge-bundle/commit/2fc7715fa4494c0b105a6399edc4877a155d3512))
* **ui/components/ErrorBoundaryScreen:** minor misspelling & update branding ([#57](https://github.com/revenge-mod/revenge-bundle/issues/57)) ([a71dd7d](https://github.com/revenge-mod/revenge-bundle/commit/a71dd7d0eb4c5e5003ff9743bcceab43ba2897c3))

## [1.5.3-dev.3](https://github.com/revenge-mod/revenge-bundle/compare/v1.5.3-dev.2...v1.5.3-dev.3) (2024-12-26)


### Bug Fixes

* change `Bunny` to `Revenge` in `ErrorBoundary` content ([89f1b18](https://github.com/revenge-mod/revenge-bundle/commit/89f1b18ebb8995f9b26e3eaa83223cea54c0bc3d))

## [1.5.3-dev.2](https://github.com/revenge-mod/revenge-bundle/compare/v1.5.3-dev.1...v1.5.3-dev.2) (2024-12-26)


### Bug Fixes

* **ui/components/ErrorBoundaryScreen:** minor misspelling & update branding ([#57](https://github.com/revenge-mod/revenge-bundle/issues/57)) ([a71dd7d](https://github.com/revenge-mod/revenge-bundle/commit/a71dd7d0eb4c5e5003ff9743bcceab43ba2897c3))

## [1.5.3](https://github.com/revenge-mod/revenge-bundle/compare/v1.5.2...v1.5.3) (2024-12-05)


* backport iOS invalid element type crash fix ([afacfa0](https://github.com/revenge-mod/revenge-bundle/commit/afacfa06480f60d461840a211c09abb363dc8546))

## [1.5.3-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.5.2...v1.5.3-dev.1) (2024-11-24)


### Bug Fixes

* **lib/ui/settings:** fix icon not showing up ([2fc7715](https://github.com/revenge-mod/revenge-bundle/commit/2fc7715fa4494c0b105a6399edc4877a155d3512))

## [1.5.2](https://github.com/revenge-mod/revenge-bundle/compare/v1.5.1...v1.5.2) (2024-11-13)


### Bug Fixes

* **lib/api/native/modules:** add new MMKVManager fallback ([a68f137](https://github.com/revenge-mod/revenge-bundle/commit/a68f1375437e164196745ad01d1997aa9ff1e67b))

## [1.5.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.5.0...v1.5.1) (2024-11-04)


### Bug Fixes

* **lib/api/native/modules:** add more native module fallbacks ([825a404](https://github.com/revenge-mod/revenge-bundle/commit/825a404cae335572aeaa713697383b7d14eca25f))

# [1.5.0](https://github.com/revenge-mod/revenge-bundle/compare/v1.4.0...v1.5.0) (2024-10-26)


### Features

* wrap `App` in `SafeAreaProvider` ([ea1aec9](https://github.com/revenge-mod/revenge-bundle/commit/ea1aec9638f0a17e67ff38bf7d79655d19835f70))

# [1.4.0](https://github.com/revenge-mod/revenge-bundle/compare/v1.3.1...v1.4.0) (2024-10-26)


### Bug Fixes

* actually fix improper FAB insets ([e987723](https://github.com/revenge-mod/revenge-bundle/commit/e9877234befc837126f4a24b23c837e7ed8f6b5b))


### Features

* port ErrorBoundary from dev ([f447910](https://github.com/revenge-mod/revenge-bundle/commit/f44791049a762fbce777b03e9d930fba0c0c6570))
* **settings/pages/Developer:** show assets types, mark non-previewable assets in AssetBrowser ([b7aacf7](https://github.com/revenge-mod/revenge-bundle/commit/b7aacf734e665a7af613aa5eaae8507ea31be5cd))

# [1.4.0-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.3.1...v1.4.0-dev.1) (2024-10-26)


### Bug Fixes

* actually fix improper FAB insets ([e987723](https://github.com/revenge-mod/revenge-bundle/commit/e9877234befc837126f4a24b23c837e7ed8f6b5b))


### Features

* port ErrorBoundary from dev ([f447910](https://github.com/revenge-mod/revenge-bundle/commit/f44791049a762fbce777b03e9d930fba0c0c6570))
* **settings/pages/Developer:** show assets types, mark non-previewable assets in AssetBrowser ([b7aacf7](https://github.com/revenge-mod/revenge-bundle/commit/b7aacf734e665a7af613aa5eaae8507ea31be5cd))

## [1.3.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.3.0...v1.3.1) (2024-10-23)


### Bug Fixes

* wrap only `FloatingActionButton` in `SafeAreaView` for `AddonPage` ([42a8268](https://github.com/revenge-mod/revenge-bundle/commit/42a8268630800d268b31f3750c3fa69d965acabc))

# [1.3.0](https://github.com/revenge-mod/revenge-bundle/compare/v1.2.0...v1.3.0) (2024-10-23)


### Bug Fixes

* wrap `addonpage` in `safeareaview` ([724fc1e](https://github.com/revenge-mod/revenge-bundle/commit/724fc1e135850d9439abcba03df1cd288ca3593b))


### Features

* improve fonts management ux ([b30e33d](https://github.com/revenge-mod/revenge-bundle/commit/b30e33d2c6be9d5fefc26903fecbf8fcccc0df42))
* show error when failing to import font entries ([9511f17](https://github.com/revenge-mod/revenge-bundle/commit/9511f174498dfa5758ad60a2e918220a685849e0))

# [1.3.0-dev.2](https://github.com/revenge-mod/revenge-bundle/compare/v1.3.0-dev.1...v1.3.0-dev.2) (2024-10-22)


### Bug Fixes

* wrap `addonpage` in `safeareaview` ([724fc1e](https://github.com/revenge-mod/revenge-bundle/commit/724fc1e135850d9439abcba03df1cd288ca3593b))

# [1.3.0-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.2.0...v1.3.0-dev.1) (2024-10-21)


### Features

* improve fonts management ux ([b30e33d](https://github.com/revenge-mod/revenge-bundle/commit/b30e33d2c6be9d5fefc26903fecbf8fcccc0df42))
* show error when failing to import font entries ([9511f17](https://github.com/revenge-mod/revenge-bundle/commit/9511f174498dfa5758ad60a2e918220a685849e0))

# [1.2.0](https://github.com/revenge-mod/revenge-bundle/compare/v1.1.2...v1.2.0) (2024-10-20)


### Bug Fixes

* **badges:** check if user is null ([a0c2ca7](https://github.com/revenge-mod/revenge-bundle/commit/a0c2ca7837c4585ead0e630d4475c354671fb8fd))
* downgrade dependencies to fix build issue ([b803053](https://github.com/revenge-mod/revenge-bundle/commit/b803053e28c77529d62179b75c22c2365869d020))
* Fix old settings menu and make some improvements to it ([#90](https://github.com/revenge-mod/revenge-bundle/issues/90)) ([e240509](https://github.com/revenge-mod/revenge-bundle/commit/e2405093eea5268d0afe88ded8735db7b5dfef43))
* load core plugins ([ed52f33](https://github.com/revenge-mod/revenge-bundle/commit/ed52f332da8a189eb1141e1f2c17f50c50562d1a))
* remove debug traces ([863466e](https://github.com/revenge-mod/revenge-bundle/commit/863466e48a741ede369a7032554191eac81e0905))
* remove parent from emitter callback ([fe937a4](https://github.com/revenge-mod/revenge-bundle/commit/fe937a4ab5631a0bb23706794511598770015e09))
* **types:** fix typescript [skip ci] ([61f9b65](https://github.com/revenge-mod/revenge-bundle/commit/61f9b6510b18032e4e91b7b2c87315d8ce6dea85))
* wrong imports ([87ba67e](https://github.com/revenge-mod/revenge-bundle/commit/87ba67e8c2a3cec6c9b03312937dfa3f5adde0f8))


### Features

* **coreplugins:** add badges ([e3df56d](https://github.com/revenge-mod/revenge-bundle/commit/e3df56dc58c8c6078269ef800d6ad899ddfa52d3))
* **metro:** expose common components & custom jsx runtime ([019fdc2](https://github.com/revenge-mod/revenge-bundle/commit/019fdc28b345e8b6f07cb96562f5e26c112da4cf))
* Rebrand to Revenge ([#51](https://github.com/revenge-mod/revenge-bundle/issues/51)) ([0a61404](https://github.com/revenge-mod/revenge-bundle/commit/0a614041327fa1232331676c40a8cd60839276ba))
* **storage:** port storage api from dev ([122c3a1](https://github.com/revenge-mod/revenge-bundle/commit/122c3a11e9f173c9c2ad9cd20d18926220428e8b))
* **ui:** ponyfill AlertModal's `extraContent` prop for older versions ([ad65247](https://github.com/revenge-mod/revenge-bundle/commit/ad6524772b9dd98f36b640b8fba2d36e2d6a7f2b)), closes [#91](https://github.com/revenge-mod/revenge-bundle/issues/91)
* **ui:** simplify some components ([4d88183](https://github.com/revenge-mod/revenge-bundle/commit/4d881835a63a64602dc0edc0332ee0097d28a601))
* **ui:** simplify unproxied notice ([1d4dfd3](https://github.com/revenge-mod/revenge-bundle/commit/1d4dfd311f4818d961b8667811bce7ecc0989152))

# [1.2.0-dev.3](https://github.com/revenge-mod/revenge-bundle/compare/v1.2.0-dev.2...v1.2.0-dev.3) (2024-10-19)


### Bug Fixes

* downgrade dependencies to fix build issue ([b803053](https://github.com/revenge-mod/revenge-bundle/commit/b803053e28c77529d62179b75c22c2365869d020))

# [1.2.0-dev.2](https://github.com/revenge-mod/revenge-bundle/compare/v1.2.0-dev.1...v1.2.0-dev.2) (2024-10-19)


### Bug Fixes

* wrong imports ([87ba67e](https://github.com/revenge-mod/revenge-bundle/commit/87ba67e8c2a3cec6c9b03312937dfa3f5adde0f8))

# [1.2.0-dev.1](https://github.com/revenge-mod/revenge-bundle/compare/v1.1.2...v1.2.0-dev.1) (2024-10-19)


### Bug Fixes

* **badges:** check if user is null ([a0c2ca7](https://github.com/revenge-mod/revenge-bundle/commit/a0c2ca7837c4585ead0e630d4475c354671fb8fd))
* Fix old settings menu and make some improvements to it ([#90](https://github.com/revenge-mod/revenge-bundle/issues/90)) ([e240509](https://github.com/revenge-mod/revenge-bundle/commit/e2405093eea5268d0afe88ded8735db7b5dfef43))
* load core plugins ([ed52f33](https://github.com/revenge-mod/revenge-bundle/commit/ed52f332da8a189eb1141e1f2c17f50c50562d1a))
* remove debug traces ([863466e](https://github.com/revenge-mod/revenge-bundle/commit/863466e48a741ede369a7032554191eac81e0905))
* remove parent from emitter callback ([fe937a4](https://github.com/revenge-mod/revenge-bundle/commit/fe937a4ab5631a0bb23706794511598770015e09))
* **types:** fix typescript [skip ci] ([61f9b65](https://github.com/revenge-mod/revenge-bundle/commit/61f9b6510b18032e4e91b7b2c87315d8ce6dea85))


### Features

* **coreplugins:** add badges ([e3df56d](https://github.com/revenge-mod/revenge-bundle/commit/e3df56dc58c8c6078269ef800d6ad899ddfa52d3))
* **metro:** expose common components & custom jsx runtime ([019fdc2](https://github.com/revenge-mod/revenge-bundle/commit/019fdc28b345e8b6f07cb96562f5e26c112da4cf))
* Rebrand to Revenge ([#51](https://github.com/revenge-mod/revenge-bundle/issues/51)) ([0a61404](https://github.com/revenge-mod/revenge-bundle/commit/0a614041327fa1232331676c40a8cd60839276ba))
* **storage:** port storage api from dev ([122c3a1](https://github.com/revenge-mod/revenge-bundle/commit/122c3a11e9f173c9c2ad9cd20d18926220428e8b))
* **ui:** ponyfill AlertModal's `extraContent` prop for older versions ([ad65247](https://github.com/revenge-mod/revenge-bundle/commit/ad6524772b9dd98f36b640b8fba2d36e2d6a7f2b)), closes [#91](https://github.com/revenge-mod/revenge-bundle/issues/91)
* **ui:** simplify some components ([4d88183](https://github.com/revenge-mod/revenge-bundle/commit/4d881835a63a64602dc0edc0332ee0097d28a601))
* **ui:** simplify unproxied notice ([1d4dfd3](https://github.com/revenge-mod/revenge-bundle/commit/1d4dfd311f4818d961b8667811bce7ecc0989152))
