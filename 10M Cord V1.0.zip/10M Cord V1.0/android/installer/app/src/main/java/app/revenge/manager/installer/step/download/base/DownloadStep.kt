package app.revenge.manager.installer.step.download.base

import android.content.Context
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import app.revenge.manager.BuildConfig
import app.revenge.manager.R
import app.revenge.manager.domain.manager.DownloadManager
import app.revenge.manager.domain.manager.DownloadResult
import app.revenge.manager.domain.manager.Mirror
import app.revenge.manager.domain.manager.PreferenceManager
import app.revenge.manager.installer.step.Step
import app.revenge.manager.installer.step.StepGroup
import app.revenge.manager.installer.step.StepRunner
import app.revenge.manager.installer.step.StepStatus
import app.revenge.manager.utils.mainThread
import app.revenge.manager.utils.showToast
import kotlinx.coroutines.CancellationException
import org.koin.core.component.inject
import java.io.File
import kotlin.math.roundToInt

/**
 * Specialized step used to download a file
 *
 * Files are downloaded to [destination] then copied to [workingCopy] for safe patching
 */
@Stable
abstract class DownloadStep : Step() {

    protected val preferenceManager: PreferenceManager by inject()

    private val downloadManager: DownloadManager by inject()
    private val context: Context by inject()

    /**
     * Url of the desired file to download
     */
    open val downloadFullUrl: String? = null

    /**
     * Mirror url path of the desired file to download
     */
    open val downloadMirrorUrlPath: String? = null

    /**
     * Where to download from when [downloadFullUrl] can't be
     */
    open val downloadFallbackUrl: String? = null

    /**
     * Where to download the file to
     */
    abstract val destination: File

    /**
     * Where the downloaded file should be copied to so that it can be used for patching
     */
    abstract val workingCopy: File

    override val group: StepGroup = StepGroup.DL

    var cached by mutableStateOf(false)
        private set

    suspend fun download(downloadUrl: String, destination: File, runner: StepRunner): Boolean {
        val fileName = destination.name
        var lastLoggedPercentage = -1
        val logIncrement = 10

        runner.logger.i("Downloading $fileName from $downloadUrl")

        val result = downloadManager.download(downloadUrl, destination) { newProgress ->
            progress = newProgress

            if (newProgress != null) {
                val currentPercentage = (newProgress * 100f).roundToInt()
                if (currentPercentage > lastLoggedPercentage && (currentPercentage % logIncrement == 0)) {
                    lastLoggedPercentage = currentPercentage
                    runner.logger.d("$fileName download progress: $currentPercentage%")
                }
            }
        }

        when (result) {
            is DownloadResult.Success -> {
                return true
            }

            is DownloadResult.Error -> {
                runner.logger.e("Current mirror ${preferenceManager.mirror.name} failed: ${result.debugReason}")
                return false
            }

            is DownloadResult.Cancelled -> {
                status = StepStatus.UNSUCCESSFUL
                if (destination.delete()) {
                    runner.logger.i("$fileName deleted from cache due to cancellation")
                }
                throw CancellationException("$fileName download cancelled")
            }
        }
    }

    /**
     * Verifies that a file was properly downloaded
     */
    open suspend fun verify() {
        if (!destination.exists())
            error("Downloaded file is missing: ${destination.absolutePath}")

        if (destination.length() <= 0)
            error("Downloaded file is empty: ${destination.absolutePath}")
    }

    override suspend fun run(runner: StepRunner) {
        val fileName = destination.name
        runner.logger.i("Checking if $fileName is cached")
        if (destination.exists()) {
            // Checked like a download: a file that isn't what this step would have downloaded isn't taken
            val usable = destination.length() > 0 && try {
                verify()
                true
            } catch (t: Throwable) {
                runner.logger.i("The cached $fileName can't be used: ${t.message}")
                false
            }
            if (usable) {
                runner.logger.i("$fileName is cached")
                cached = true

                runner.logger.i("Moving $fileName to working directory")
                destination.copyTo(workingCopy, true)

                status = StepStatus.SUCCESSFUL
                return
            }

            runner.logger.i("Deleting cached file: $fileName")
            destination.delete()
        }

        runner.logger.i("$fileName was not properly cached, downloading now")

        val devMirror = BuildConfig.DEV_MIRROR_URL.takeIf { it.isNotEmpty() }
        var downloadUrl = if (downloadMirrorUrlPath != null) {
            (devMirror ?: preferenceManager.mirror.baseUrl) + downloadMirrorUrlPath
        } else {
            downloadFullUrl
        }

        var successfulDownload = download(downloadUrl!!, destination, runner)

        // A development mirror that doesn't have the file falls through to the public mirrors
        if (!successfulDownload && devMirror != null && downloadMirrorUrlPath != null) {
            downloadUrl = preferenceManager.mirror.baseUrl + downloadMirrorUrlPath
            successfulDownload = download(downloadUrl, destination, runner)
        }

        // An address of one build can be gone once a later build replaced it
        val fallbackUrl = downloadFallbackUrl
        if (!successfulDownload && fallbackUrl != null) {
            downloadUrl = fallbackUrl
            successfulDownload = download(fallbackUrl, destination, runner)
        }

        // If the current mirror fails, try other mirrors
        if (!successfulDownload && downloadMirrorUrlPath != null) {
            for (mirror in Mirror.entries - preferenceManager.mirror) {
                downloadUrl = mirror.baseUrl + downloadMirrorUrlPath
                runner.logger.i("Trying mirror: ${mirror.name}")
        
                if (download(downloadUrl, destination, runner)) {
                    preferenceManager.mirror = mirror
                    successfulDownload = true
                    break
                }
            }
        }

        if (!successfulDownload) {
            mainThread {
                context.showToast(R.string.msg_download_failed)
                runner.downloadErrored = true
            }
            throw Error("Failed to download $fileName from all mirrors.")
        }

        try {
            runner.logger.i("Verifying downloaded file")
            verify()
            runner.logger.i("$fileName downloaded successfully")
        } catch (t: Throwable) {
            mainThread {
                context.showToast(R.string.msg_download_verify_failed)
            }
            throw t
        }

        runner.logger.i("Moving $fileName to working directory")
        destination.copyTo(workingCopy, true)
    }
}