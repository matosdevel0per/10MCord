# 10MCord — branding notes

This is a community rebrand of the Endcord Mobile source tree, not an official Endcord release.

## Changes made
- Android installer display name: **10MCord Installer**
- Installer application ID: `com.tenmcord.installer`
- Gradle output base name: `10MCord`
- Installer's displayed mod name: `10MCord`
- Visible installer strings updated in the bundled locale resource files.

## Important build/runtime note
The installer still downloads the upstream Endcord loader and bundle from the original
Endcord Mobile release URLs, and its repository/about links still point to the upstream
project. This branding-only source change does **not** create a separately maintained
10MCord loader or backend. Do not publish it as an official Endcord build.

## Build
Open `android/installer/` in Android Studio and build the `app` release variant.
The APK output is named `10MCord-1.0.3.apk` (version may change with `gradle.properties`).
The project uses the original source licenses and notices; retain them when redistributing.

## Upstream
https://github.com/Endcord/endcord-mobile
